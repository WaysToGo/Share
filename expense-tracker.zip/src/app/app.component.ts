import { Component } from '@angular/core';

@Component({
  selector: 'expense-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'expense-tracker';
}
