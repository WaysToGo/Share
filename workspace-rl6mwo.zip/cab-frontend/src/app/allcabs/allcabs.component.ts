import { Component, OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';
import { MatTableDataSource } from '@angular/material';
import { Details } from '../details.component';

@Component({
  selector: 'app-allcabs',
  templateUrl: './allcabs.component.html',
  styleUrls: ['./allcabs.component.css']
})
export class AllcabsComponent implements OnInit {

  
  ngOnInit(): void {
    this.getAllDetails();
  }
  details: any = [];
  displayedColumns = ['id', 'name', 'mobile', 'email', 'cabnumber','cabtype','buttons'];
  dataSource = '';

 
  data = {
    id: '',
    name: '',
    mobile: '',
    email: '',
    cabnumber:'',
    cabtype:''

  }


  constructor(private http: Http) {
  }

  getAllDetails = function () {
    this.http.get('/cab-latest/api/cabs/').subscribe((res: Response) => {
      let body = res.json();
      this.details = body;
      this.dataSource = new MatTableDataSource < Details > (this.details);
    })
  };




  deleteDetails(name) {
    this.http.delete('/cab-latest/api/cabs/' + name).subscribe((res: Response) => {
      this.getAllDetails();

    })
  }

}
