import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import { FormsModule }   from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import {MatTableModule} from '@angular/material/table';
import {MatCardModule} from '@angular/material/card';
import { AllcabsComponent } from './allcabs/allcabs.component';
import { RouterModule } from '@angular/router';
import { CabregistrationComponent } from './cabregistration/cabregistration.component';
import { NearbycabComponent } from './nearbycab/nearbycab.component';



@NgModule({
  declarations: [
    AppComponent,
    AllcabsComponent,
    CabregistrationComponent,
    NearbycabComponent
  ],
  imports: [
    BrowserModule,
    MatInputModule,
    FormsModule,
    NoopAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    HttpModule,
    MatTableModule,
    MatCardModule,
    RouterModule.forRoot([
      
      { path: '*', component: AppComponent },
      { path: 'allcabs', component: AllcabsComponent },
      { path: 'registration', component: CabregistrationComponent },
      { path:'bookcab',component:NearbycabComponent}
      
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {  

}
