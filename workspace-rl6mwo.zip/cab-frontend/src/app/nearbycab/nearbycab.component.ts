import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

@Component({
  selector: 'app-nearbycab',
  templateUrl: './nearbycab.component.html',
  styleUrls: ['./nearbycab.component.css']
})
export class NearbycabComponent implements OnInit {

  details:any=[];
  detail:any=[];
  length = 1000000;
 
  constructor(private http:Http) { }

  ngOnInit() {
    this.getAllDetails();
    
  }


  getAllDetails = function () {
    this.http.get('/cab-latest/api/cabs/').subscribe((res: Response) => {
      let body = res.json();
      this.details = body;
      this.details.filter(a => {
         
        if (a.distance < this.length) {
          this.length = a.distance;
          if(this.detail.length==0){
            this.detail.push(a);
          }
          else{
            this.detail.pop();
            this.detail.push(a);
          }
           
          return true;
        }
        
      })
      this.length = 1000000;
    })
  };


  


}
