package com.example.demo;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import net.minidev.json.JSONObject;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CabAppRestTest {

	
public String url="http://localhost:8000/cab-latest/api/cabs/";



	@Test
	public void testOrder1() throws Exception {
		
		 given().get(url).then().statusCode(200);
	      
		 

	}
	
	@Test
	public void testOrder2() throws Exception {
		
		JSONObject requestParams = new JSONObject();
		requestParams.put("id", 111111111);
		requestParams.put("name", "test1");
		
		requestParams.put("mobile", "2222222222");
		requestParams.put("email", "123@gmail.com");
		requestParams.put("cabnumber", "KA12PA8988");
		requestParams.put("cabtype", "mini");
		given().header("Content-Type", "application/json").body(requestParams.toJSONString()).post(url);

		
		
		 given().get(url+"111111111").then().statusCode(200).body("mobile",is("2222222222"));
		 given().get(url+"111111111").then().statusCode(200).body("cabnumber",is("KA12PA8988"));
		 

	}
		
	
	@Test
	public void testOrder3() throws Exception {
		
	
		 given().delete(url+"111111111").then().statusCode(200);

	}
	
	
	
	
}
