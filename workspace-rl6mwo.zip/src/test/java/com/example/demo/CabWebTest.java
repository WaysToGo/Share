package com.example.demo;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;



@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CabWebTest {
	public DesiredCapabilities caps;
	public WebDriver driver;
	public String url="http://localhost:8000/cab-latest/";
		@Before
	public void init() {
		caps = new DesiredCapabilities();
		caps.setJavascriptEnabled(true);
		caps.setCapability("takesScreenshot", true);
    final ChromeOptions chromeOptions = new ChromeOptions();
    // chromeOptions.setBinary("/opt/chromedriver");
    chromeOptions.addArguments("--headless");
    chromeOptions.addArguments("--disable-gpu");
    chromeOptions.addArguments("--no-sandbox");
    caps.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
    System.setProperty("webdriver.chrome.driver", "/opt/chromedriver");
    
//    System.setProperty("webdriver.chrome.driver", "D:\\projects\\impfile\\chromedriver.exe");
    driver = new ChromeDriver(caps);


		
	}

	 
	  @Test
	  public void testOrder1() throws InterruptedException {
		  driver.get(url);
		  
			driver.findElement(By.id("id")).click();
		    driver.findElement(By.id("id")).clear();
		    driver.findElement(By.id("id")).sendKeys("2000");
		    driver.findElement(By.id("name")).click();
		    driver.findElement(By.id("name")).clear();
		    driver.findElement(By.id("name")).sendKeys("test123");
		    driver.findElement(By.id("email")).click();
		    driver.findElement(By.id("email")).clear();
		    driver.findElement(By.id("email")).sendKeys("test123@gmail.com");
		    driver.findElement(By.id("mobile")).click();
		    driver.findElement(By.id("mobile")).clear();
		    driver.findElement(By.id("mobile")).sendKeys("9999999910");
		    driver.findElement(By.id("cabnumber")).click();
		    driver.findElement(By.id("cabnumber")).clear();
		    driver.findElement(By.id("cabnumber")).sendKeys("KA12PA8988");
		    driver.findElement(By.id("cabtype")).click();
		    driver.findElement(By.id("cabtype")).clear();
		    driver.findElement(By.id("cabtype")).sendKeys("any");
		    driver.findElement(By.id("submit")).click();
		    Thread.sleep(5000);
		    List<WebElement> beforeData = driver.findElements(By.className("delete-btn"));
			   int beforeCount= beforeData.size();
		    
			   driver.findElement(By.id("id")).click();
			    driver.findElement(By.id("id")).clear();
			    driver.findElement(By.id("id")).sendKeys("2002");
			    driver.findElement(By.id("name")).click();
			    driver.findElement(By.id("name")).clear();
			    driver.findElement(By.id("name")).sendKeys("test123");
			    driver.findElement(By.id("email")).click();
			    driver.findElement(By.id("email")).clear();
			    driver.findElement(By.id("email")).sendKeys("test123@gmail.com");
			    driver.findElement(By.id("mobile")).click();
			    driver.findElement(By.id("mobile")).clear();
			    driver.findElement(By.id("mobile")).sendKeys("9999999910");
			    driver.findElement(By.id("cabnumber")).click();
			    driver.findElement(By.id("cabnumber")).clear();
			    driver.findElement(By.id("cabnumber")).sendKeys("KA12PA8988");
			    driver.findElement(By.id("cabtype")).click();
			    driver.findElement(By.id("cabtype")).clear();
			    driver.findElement(By.id("cabtype")).sendKeys("any");
			    driver.findElement(By.id("submit")).click();
		    Thread.sleep(5000);
		    List<WebElement> afterData = driver.findElements(By.className("delete-btn"));
			   int afterCount= afterData.size();
		    
		    
			   assertEquals(beforeCount+1,afterCount);
		    
			   driver.findElements(By.className("delete-btn")).get(0).click();
			   		   
			driver.close();
			  }


	  
	  @Test 
	  public void testOrder2() throws InterruptedException {
		  driver.get(url);
		  List<WebElement> data = driver.findElements(By.className("delete-btn"));
		   int count= data.size();
		   count-=1;
		   
		   driver.findElements(By.className("delete-btn")).get(0).click();
		   Thread.sleep(5000);
		   List<WebElement> afterdata = driver.findElements(By.className("delete-btn"));
		   int aftercount= afterdata.size();

		  
		   
		   assertEquals(count,aftercount);
		    driver.close();
	  }
	  


}

