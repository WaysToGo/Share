import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllcabsComponent } from './allcabs.component';

describe('AllcabsComponent', () => {
  let component: AllcabsComponent;
  let fixture: ComponentFixture<AllcabsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllcabsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllcabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
