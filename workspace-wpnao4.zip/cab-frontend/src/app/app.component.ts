import { Component } from '@angular/core';
import {MatTableDataSource} from '@angular/material';
import { Http,Response,RequestOptions } from '@angular/http';
import {Details} from './details.component';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

}
