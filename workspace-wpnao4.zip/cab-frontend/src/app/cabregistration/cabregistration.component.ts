import { Component, OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';
import { MatTableDataSource } from '@angular/material';
import { Details } from '../details.component';

@Component({
  selector: 'app-cabregistration',
  templateUrl: './cabregistration.component.html',
  styleUrls: ['./cabregistration.component.css']
})
export class CabregistrationComponent implements OnInit {

  
    ngOnInit(): void {
      this.getAllDetails();
    }
    details: any = [];
    displayedColumns = ['id', 'name', 'mobile', 'email', 'cabnumber','cabtype','buttons'];
    dataSource = '';
  
   
    data = {
      id: '',
      name: '',
      mobile: '',
      email: '',
      cabnumber:'',
      cabtype:''
  
    }
  
  
    constructor(private http: Http) {
    }
  
    getAllDetails = function () {
      this.http.get('/cab-latest/api/cabs/').subscribe((res: Response) => {
        let body = res.json();
        this.details = body;
        this.dataSource = new MatTableDataSource < Details > (this.details);
      })
    };
  
  
  
    addDetails(data) {
      let headers = new Headers({
        'Content-Type': 'application/json'
      });
  
      this.http.post('/cab-latest/api/cabs/', {
        "id": data.id,
        "name": data.name,
        "mobile": data.mobile,
        "email": data.email,
        "cabnumber":data.cabnumber,
        "cabtype":data.cabtype,
        "distance":Math.floor(Math.random() * 100)
      }).subscribe((res: Response) => {
        this.data.id = '';
        this.data.name = '';
        this.data.mobile = '';
        this.data.email = '';
        this.data.cabnumber = '';
        this.data.cabtype = '';
  
        this.getAllDetails();
      })
    };
  
    deleteDetails(name) {
      this.http.delete('/cab-latest/api/cabs/' + name).subscribe((res: Response) => {
        this.getAllDetails();
  
      })
    }
  
}
