

export interface Details {
    id: number;
    name:string;
    mobile:string;
    email:string;
    cabnumber:string;
    cabtype:string;
  }
 