import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NearbycabComponent } from './nearbycab.component';

describe('NearbycabComponent', () => {
  let component: NearbycabComponent;
  let fixture: ComponentFixture<NearbycabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NearbycabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NearbycabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
