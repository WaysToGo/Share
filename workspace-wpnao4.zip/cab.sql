    create database restdb;
    use restdb;