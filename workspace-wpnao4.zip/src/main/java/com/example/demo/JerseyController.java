package com.example.demo;

import java.net.URI;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
@Path("/cabs")
public class JerseyController {
	@Autowired
	Cabrepo cabrepo;
	
	
	
	  @GET
	    @Produces("application/json")
	    public List<CabModel> getAlldetails() {		
	        return cabrepo.findAll();
	    }
	  
	  @POST
	  @Consumes("application/json")
	  @Produces("application/json")
	     public Response saveAlldetails(CabModel details){		 
		  cabrepo.save(details);
		  return Response.created(URI.create("/" + details.getId())).build();
		  
	  }
	  
	  
	  @GET
	  @Path("/{id}")
	    @Produces("application/json")
	    public CabModel getDetails(@PathParam("id") int id) {	 	
	        return cabrepo.findOne(id);
	        }
	  
	  
	  @PUT
	  @Path("/{id}")
	  @Consumes("application/json")
	  @Produces("application/json")
	  public Response saveDetails(@PathParam("id") int id,CabModel Details){
		  
			Details.setId(id);
			 cabrepo.save(Details);
 		  return Response.noContent().build();
		  
	  }
	  
	  
	  @DELETE
	  @Path("/{id}")
	  public Response deletedetails(@PathParam("id") int id){		  
		  cabrepo.delete(id);
		  
		 return Response.ok().build();
		  
	  }
	  

	  
	  


}
